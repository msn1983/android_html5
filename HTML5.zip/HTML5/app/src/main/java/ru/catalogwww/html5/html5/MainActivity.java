package ru.catalogwww.html5.html5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {
    protected WebView myWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

                /* Находим наш браузер */
        myWeb= (WebView) findViewById(R.id.webView);
        /* Настраиваем наш браузер */
        myWeb.getSettings().setUseWideViewPort(true);
        myWeb.setInitialScale(1);
        myWeb.getSettings().setJavaScriptEnabled(true);
        /* Загружаем страничку */
        myWeb.loadUrl("file:///android_asset/index.html");
    }


}